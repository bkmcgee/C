#include <stdio.h>
int main()
{
   int j,num;
   printf("\n::::::Question 7:::::\n" );
   printf("Please enter your natural number: ");
   scanf("%d",&num);
   printf("\n\n");
   for(j=1;j<=1;j++)
   {
     printf("%d X %d = %d \n",num,50,num*50);
     printf("%d X %d = %d \n",num,20,num*20);
     printf("%d X %d = %d \n",num,10,num*10);
     printf("%d X %d = %d \n",num,1,num*1);
   }
   return 0;
}
