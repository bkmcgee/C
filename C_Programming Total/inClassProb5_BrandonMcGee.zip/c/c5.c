#include <stdio.h>

int main ()
{
  printf("           '__'\n" );
  printf("           (oo)\n" );
  printf("   +========\\/\n" );
  printf(" // || %c%c%c || \n",37,37,37 );
  printf("*   ||-----||\n" );
  printf("    ""      ""\n");

  return 0;
}
